package io.codeforall.ironMaven;

public class Dealer {
    Card[] cardDeck;

}
