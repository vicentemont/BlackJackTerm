package io.codeforall.ironMaven;

public enum Suit {
    CLUBS,
    DIAMONDS,
    HEARTS,
    SPADES;
}
